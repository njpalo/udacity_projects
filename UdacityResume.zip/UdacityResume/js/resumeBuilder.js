var bio = {
    "name" : "Nicholas Paloski",
    "role" : "entry level software developer",
    "contacts" : {
        "mobile": "832-439-1000",
        "email": "njpalo@gmail.com",
        "github": "njpalo",
        "location": "Houston, TX"
    },
    "welcomeMessage": "Hello, World!",
    "skills": ["HTML, CSS, JavaScript and Python", "Electrical Systems", "Solar Panel Installation", "SketchUp 3D",
        "Project Management", "Structural Design", "Pricing and Cost Estimates", "Surveys and Inspections"
    ],
    "biopic": "images/2017portrait.jpg",
    display : function() {
        var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
        $("#header").append(formattedBioPic);
        var formattedName = HTMLheaderName.replace("%data%", bio.name);
        $("#header").append(formattedName);
        var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
        $("#header").append(formattedRole);
        var formattedMsg = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
        $("#header").append(formattedMsg);
        var formattedMobile = HTMLmobile.replace("%data%", bio.contacts.mobile);
        var formattedEmail = HTMLemail.replace("%data%", bio.contacts.email);
        var formattedGithub = HTMLgithub.replace("%data%", bio.contacts.github);
        var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);
        $("#topContacts, #footerContacts").append(formattedMobile, formattedEmail, formattedGithub, formattedLocation);
        if(bio.skills.length > 0) {
            $("#header").append(HTMLskillsStart);
        }
        bio.skills.forEach(function(skill) {
            var formattedSkill = HTMLskills.replace("%data%", skill);
            $("#skills").append(formattedSkill);
        });
    }
};
var work = {
    "jobs": [
        {
            "employer": "Adaptive Solar Design",
            "title": "co-founder / designer / project manager",
            "location": "Houston, TX",
            "dates": " March 2011 - February 2017",
            "description": "I co-founded this solar photovoltaic installation business and served as "+
                           "system designer, project manager and lead installer for 6 years. During "+
                           "that time we installed roughly 10,000 solar panels for over 2 Megawatts "+
                           "of total capacity. This was about 50% residential and 50% commercial. "+
                           "The larger projects included 244kW @ the Palmer Event Center in Austin "+
                           "and 197kW @ the Mickey Leland Federal Building in downtown Houston."
        },
        {
            "employer": "Urban Outfitters",
            "title": "Display Artist",
            "location": "Houston, TX",
            "dates": "July 2002 - March 2011",
            "description": "A Display Artist is essentially a carpenter, graphic artist and all around "+
                           "handyman. My job was to continuously update the look and feel of the store, "+
                           "very much like changing sets during a theater production. I also traveled "+
                           "extensively for this job, spending 2 or 3 months per year on the road, "+
                           "opening new stores all around the country and prototyping new displays at "+
                           "the flagship stores in Philidelphia, New York and Los Angeles."
        },
        {
            "employer": "Starbucks",
            "title": "Shift Manager",
            "location": "Houston, TX",
            "dates": "May 2001 - July 2002",
            "description": "Worked as a Barista and Shift Manager back when Starbucks still had real "+
                           "espresso machines. Made coffee, set schedules, ordered product and "+
                           "managed small crews of employees. "
        }
    ],
    display : function() {
        for(var i = 0; i < work.jobs.length; i++) {
            $("#workExperience").append(HTMLworkStart);
            var formattedEmployer = HTMLworkEmployer.replace("%data%", work.jobs[i].employer);
            var formattedTitle = HTMLworkTitle.replace("%data%", work.jobs[i].title);
            var formattedEmployerTitle = formattedEmployer + formattedTitle;
            $(".work-entry:last").append(formattedEmployerTitle);
            var formattedLocation = HTMLworkLocation.replace("%data%", work.jobs[i].location);
            $(".work-entry:last").append(formattedLocation);
            var formattedDates = HTMLworkDates.replace("%data%", work.jobs[i].dates);
            $(".work-entry:last").append(formattedDates);
            var formattedDescription = HTMLworkDescription.replace("%data%", work.jobs[i].description);
            $(".work-entry:last").append(formattedDescription);
        }
    }
};
var projects = {
    "projects": [
        {
            "title": "Palmer Event Center 244 kW Solar PV Inatallation",
            "dates": "summer 2013",
            "description": "Adaptive Solar Design was contracted by Solar Community to install "+
                           "racking, solar modules and DC side electrical for this 244 kW solar "+
                           "project in Austin, TX. I ended up modifying the strutural layout "+
                           "because the original layout did not fit as designed. "+
                           "As a result, I ended up completely redesigning the DC electrical "+
                           "layout to fit the new structural layout.",
            "images": ["images/PalmerProgress.jpg", "images/PalmerFinal.png"]
        }
    ],
    display: function() {
        for(var i = 0; i < projects.projects.length; i++) {
            $("#projects").append(HTMLprojectStart);
            var formattedTitle = HTMLprojectTitle.replace("%data%", projects.projects[i].title);
            $(".project-entry:last").append(formattedTitle);
            var formattedDates = HTMLprojectDates.replace("%data%", projects.projects[i].dates);
            $(".project-entry:last").append(formattedDates);
            var formattedDescription = HTMLprojectDescription.replace("%data%", projects.projects[i].description);
            $(".project-entry:last").append(formattedDescription);
            for(var j = 0; j < projects.projects[i].images.length; j++) {
                var formattedImage = HTMLprojectImage.replace("%data%", projects.projects[i].images[j]);
                $(".project-entry:last").append(formattedImage);
            }
        }
    }
};
var education = {
    "schools": [
        {
            "name": "Texas A&M University",
            "location": "College Station, TX",
            "dates": "fall 1997 - spring 2000",
            "majors": ["Mechanical Engineering Technology"],
            "degree": "none"
        },
        {
            "name": "Clear Creek High School",
            "location": "League City, TX",
            "dates": "graduated 1997",
            "majors": ["n/a"],
            "degree": "n/a"
        }
    ],
    "onlineClasses": [
        {
            "title": "Intro to Programming Nanodegree",
            "school": "Udacity",
            "dates": "in progress",
            "url": "https://www.udacity.com"
        }
    ],
    display: function() {
        for(var i = 0; i < education.schools.length; i++) {
            $("#education").append(HTMLschoolStart);
            var formattedName = HTMLschoolName.replace("%data%", education.schools[i].name);
            $(".education-entry:last").append(formattedName);
            var formattedDates = HTMLschoolDates.replace("%data%", education.schools[i].dates);
            $(".education-entry:last").append(formattedDates);
            var formattedLocation = HTMLschoolLocation.replace("%data%", education.schools[i].location);
            $(".education-entry:last").append(formattedLocation);
            var formattedMajors = HTMLschoolMajor.replace("%data%", education.schools[i].majors);
            $(".education-entry:last").append(formattedMajors);
            var formattedDegree = HTMLschoolDegree.replace("%data%", education.schools[i].degree);
            $(".education-entry:last").append(formattedDegree);
        }
        if(education.onlineClasses.length > 0) {
            $("#education").append(HTMLschoolStart);
            $("#education").append(HTMLonlineClasses);
        }
        for(var j = 0; j < education.onlineClasses.length; j++) {
            $("#education").append(HTMLschoolStart);
            var formattedTitle = HTMLonlineTitle.replace("%data%", education.onlineClasses[j].title);
            $(".education-entry:last").append(formattedTitle);
            var formattedSchool = HTMLonlineSchool.replace("%data%", education.onlineClasses[j].school);
            $(".education-entry:last").append(formattedSchool);
            var formattedOnlineDates = HTMLonlineDates.replace("%data%", education.onlineClasses[j].dates);
            $(".education-entry:last").append(formattedOnlineDates);
            var formattedURL = HTMLonlineURL.replace("%data%", education.onlineClasses[j].url);
            $(".education-entry:last").append(formattedURL);
        }
    }
};
bio.display();
work.display();
projects.display();
education.display();
$("#mapDiv").append(googleMap);